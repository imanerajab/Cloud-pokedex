package com.ai;

import java.io.IOException;
import java.util.Collections;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.jsr107cache.Cache;
import net.sf.jsr107cache.CacheManager;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Transaction;

@SuppressWarnings("serial")
public class AfficheStatServlet extends HttpServlet {
	
	public static HttpServletResponse resp;
	public DatastoreService datastore= DatastoreServiceFactory.getDatastoreService();
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException {
		resp.setContentType("text/plain");
		
		
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException {
		
		try
		{
			Cache cache = CacheManager.getInstance().getCacheFactory().createCache(Collections.emptyMap());
			if(!cache.isEmpty())
			{
				String html = "<html>";
				Query q = new Query("Statistique");
				q.addSort("Pourcentage", Query.SortDirection.DESCENDING);
				PreparedQuery pq = datastore.prepare(q);
				
				
				html+="<TABLE BORDER=\"1\"> <CAPTION> Pourcentage des Pokemon poss&eacuted&eacutes </CAPTION>";
				html+="<TR> <TH> Type </TH> <TH> Pourcentage </TH> </TR> ";
				for (Entity result : pq.asIterable()) {
					String type = (String) result.getProperty("Type");
					Double pourcentage = (Double) result.getProperty("Pourcentage");	
					html+= "<TR> <TH> "+ type +" </TH> <TD> "+pourcentage+"% </TD></TR>  ";
				}
				
				html+="</TABLE></html>";
				
				resp.getWriter().println(html);
			}
			else
			{
				String html = "<html>";
				html+="<TABLE BORDER=\"1\"> <CAPTION> Pourcentage des Pokemon poss&eacuted&eacutes </CAPTION>";
				html+="<TR> <TH> Type </TH> <TH> Pourcentage </TH> </TR> ";
				for (Object o : cache.keySet())
				{
					if(o instanceof Entity)
					{
						Entity e = (Entity)o;
						String type = (String) e.getProperty("Type");
						Double pourcentage = (Double) e.getProperty("Pourcentage");	
						html+= "<TR> <TH> "+ type +" </TH> <TD> "+pourcentage+"% </TD></TR>  ";
					}
				}
				resp.getWriter().println(html);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
	}
}
