package com.ai;

import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Transaction;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.TaskOptions;
import com.google.appengine.api.taskqueue.TaskOptions.Method;
import com.google.appengine.api.taskqueue.TaskQueuePb.TaskQueueFetchQueuesResponse.Queue;

@SuppressWarnings("serial")
public class PokemonServlet extends HttpServlet {
	
	public static HttpServletResponse resp;
	public DatastoreService datastore= DatastoreServiceFactory.getDatastoreService();
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException {
		resp.setContentType("text/plain");
		
		
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException {
		
		datastore = DatastoreServiceFactory.getDatastoreService();
		String numero = req.getParameter("Numero");
		String nom = req.getParameter("Nom");
		String type1 = req.getParameter("Type1");
		String type2 = req.getParameter("Type2");
		String evolution = req.getParameter("Evolution");
		String ssevolution = req.getParameter("ssEvolution");
		
		Transaction txn= datastore.beginTransaction();
		if(nom!=null && type1!=null) {
				Entity e = new Entity("Pokemon", nom);

				try {
					
				e.setProperty("Nom", nom);
				e.setProperty("Numero", numero);
				e.setProperty("Type1", type1);
				e.setProperty("Type2", type2);
				if(evolution!=null){e.setProperty("Evolution", evolution);}else{e.setProperty("Evolution", "Aucune");}
				if(ssevolution!=null){e.setProperty("ssEvolution", ssevolution);}else{e.setProperty("ssEvolution", "Aucune");}
				
				com.google.appengine.api.taskqueue.Queue queue = QueueFactory.getDefaultQueue();
				queue.add(TaskOptions.Builder.withUrl("/calculerstats").param("Type1", type1).param("Type2", type2).method(Method.POST));
				
				datastore.put(e);
				txn.commit();
				
				resp.getWriter().println(
					nom + " a ete ajoute au Pokedex");
				
				}
				finally
				{
					if(txn.isActive()){txn.rollback();}
				}
					
		}
		
		
	}
	
	
}
