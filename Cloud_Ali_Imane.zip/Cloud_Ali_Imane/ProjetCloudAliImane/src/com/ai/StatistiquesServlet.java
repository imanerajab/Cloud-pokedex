package com.ai;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;





import java.util.Map;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.jsr107cache.Cache;
import net.sf.jsr107cache.CacheManager;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Transaction;

@SuppressWarnings("serial")
public class StatistiquesServlet extends HttpServlet {
	
	public static HttpServletResponse resp;
	public DatastoreService datastore= DatastoreServiceFactory.getDatastoreService();
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException {
		resp.setContentType("text/plain");
		
		
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException {
		
		Query q = new Query("Pokemon");
		q.addSort("Numero", Query.SortDirection.ASCENDING);
		PreparedQuery pq = datastore.prepare(q);
		int compteur = 0;
		HashMap<String, Integer> h = new HashMap<String, Integer>();
		
		String type1 = req.getParameter("Type1");
		String type2 = req.getParameter("Type2");
		/*compteur++;
		
		if(!type1.equals("Aucun"))
		{
			if(h.get(type1)==null)
			{
				h.put(type1, new Integer(1));
			}
			else
			{
				h.put(type1, h.get(type1)+1);
			}
		}
		if(!type2.equals("Aucun"))
		{
			compteur++;
			if(h.get(type2)==null)
			{
				h.put(type2, new Integer(1));
			}
			else
			{
				h.put(type2, h.get(type2)+1);
			}
		}
		*/
		for (Entity result : pq.asIterable()) {
			compteur++;
			type1 = (String) result.getProperty("Type1");
			type2 = (String) result.getProperty("Type2");
			
			if(!type1.equals("Aucun"))
			{
				if(h.get(type1)==null)
				{
					h.put(type1, new Integer(1));
				}
				else
				{
					h.put(type1, h.get(type1)+1);
				}
			}
			if(!type2.equals("Aucun"))
			{
				compteur++;
				if(h.get(type2)==null)
				{
					h.put(type2, new Integer(1));
				}
				else
				{
					h.put(type2, h.get(type2)+1);
				}
			}
		}
		
		Query query = new Query("Statistique");
		PreparedQuery pquery = datastore.prepare(query);
		for (Entity result : pquery.asIterable())
		{
			datastore.delete(result.getKey());
		}
		HashMap<Entity, Double> map = new HashMap<Entity, Double>();
		
		
		for(String type:h.keySet())
		{
			int nombre = h.get(type).intValue();
			double pourcentage = ((double)((int)((double)nombre*1000/(double)compteur)))/10;
			Transaction txn= datastore.beginTransaction();
			Entity e = new Entity("Statistique", type);
			
			try
			{
				
				e.setProperty("Type", type);
				e.setProperty("Pourcentage", pourcentage);
				map.put(e,pourcentage);
				datastore.put(e);
				txn.commit();
			}
			finally
			{
				if(txn.isActive()){txn.rollback();}
			}
		}
		try
		{
			Map props = new HashMap();
			props.put(com.google.appengine.api.memcache.stdimpl.GCacheFactory.EXPIRATION_DELTA, 3600); // le cache restera une heure
			
			Cache cache = CacheManager.getInstance().getCacheFactory().createCache(props);
			cache.putAll(map);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		resp.sendRedirect("index.html");
		
	}
}
