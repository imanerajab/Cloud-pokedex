package com.ai;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.google.appengine.api.NamespaceManager;



public class NameSpaceFilter implements Filter {
	public static String client_static;
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1,
			FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		String client = arg0.getParameter("client");
		if(client!=null){client_static = client;}
		/*if(NamespaceManager.get()==null)
		{*/
			NamespaceManager.set(client_static);
		//}
		
		chain.doFilter(arg0, arg1);

	}
	
	

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}

}
