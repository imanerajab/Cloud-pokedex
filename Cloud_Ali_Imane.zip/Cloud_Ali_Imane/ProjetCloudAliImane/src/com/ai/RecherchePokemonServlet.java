package com.ai;

import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Transaction;

@SuppressWarnings("serial")
public class RecherchePokemonServlet extends HttpServlet {
	
	public static HttpServletResponse resp;
	public DatastoreService datastore= DatastoreServiceFactory.getDatastoreService();
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException {
		resp.setContentType("text/plain");
		
		
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException {
		
		String html = "<html>";
		String recherche = req.getParameter("Nom");
		Query q = new Query("Pokemon");
		PreparedQuery pq = datastore.prepare(q);
		
		
		html+="<TABLE BORDER=\"1\"> <CAPTION> Liste des pokemons </CAPTION>";
		html+="<TR> <TH> Nom </TH> <TH> Numero </TH> <TH> Type 1 </TH> <TH> Type 2 </TH> <TH> Evolution </TH> <TH> ssEvolution </TH> </TR> ";
		for (Entity result : pq.asIterable()) {
			String nom = (String) result.getProperty("Nom");
			if(nom.toLowerCase().contains(recherche.toLowerCase()))
			{
				Long numero =  Long.parseLong((String)result.getProperty("Numero"));
				String type1 = (String) result.getProperty("Type1");
				String type2 = (String) result.getProperty("Type2");			
				 String evolution = (String) result.getProperty("Evolution");
				String ssevolution = (String) result.getProperty("ssEvolution");			html+= "<TR> <TH> "+ nom +" </TH> <TD> "+numero+" </TD> <TD> "+type1+" </TD> <TD> "+type2+" </TD> <TD>"+evolution+"</TD> <TD>"+ssevolution+" </TD></TR>  ";
			//resp.getWriter().println("<TR> <TH> "+ nom +" </TH> <TD> Valeur B2 </TD> <TD> Valeur B3 </TD> <TD> Valeur B4 </TD> </TR>  ");
		
			}
		}
		
		html+="</TABLE></html>";
		
		resp.getWriter().println(html);
	}
}
